import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import { cookies, headers } from "next/headers";
import AskTalap from "@/components/AskTalap";
import { LocaleProvider } from "@/components/i18n/LocaleProvider";
import SessionProvider from "@/components/auth/SessionProvider";
import {
  DEFAULT_LOCALE,
  LOCALE_COOKIE,
  LOCALE_TAG,
  isLocale,
  localeFromAcceptLanguage,
  translate,
  type Locale,
} from "@/lib/i18n";
import "./globals.css";

const inter = Inter({
  // "latin-ext" and "cyrillic-ext" carry the Kazakh letters — ә ғ қ ң ө ұ ү һ і.
  // Without cyrillic-ext the Kazakh locale falls back to a system face mid-word,
  // which is visible and ugly.
  subsets: ["latin", "latin-ext", "cyrillic", "cyrillic-ext"],
  display: "swap",
  variable: "--font-inter",
});

/**
 * Resolve the locale before the first byte goes out.
 *
 * Cookie beats header beats default, so a student who has chosen Kazakh once
 * never sees a flash of Russian on the next visit.
 */
async function resolveLocale(): Promise<Locale> {
  const store = await cookies();
  const saved = store.get(LOCALE_COOKIE)?.value;
  if (isLocale(saved)) return saved;

  const h = await headers();
  return localeFromAcceptLanguage(h.get("accept-language")) ?? DEFAULT_LOCALE;
}

export async function generateMetadata(): Promise<Metadata> {
  const locale = await resolveLocale();
  const t = (key: string) => translate(locale, key);

  return {
    title: `Talap — ${t("landing.title.a")} ${t("landing.title.b")}`,
    description: t("landing.sub"),
    keywords: [
      "NIS",
      "МЭСК",
      "Cambridge",
      "Nazarbayev Intellectual Schools",
      "exam prep",
      "ҰБТ",
      "сынақ",
    ],
    // The site is one URL per page in all three locales — the locale is a
    // cookie, not a path — so alternates point at the same href with different
    // hreflang, which is what tells crawlers the page is multilingual.
    alternates: {
      canonical: "https://talap.online/",
      languages: {
        kk: "https://talap.online/",
        ru: "https://talap.online/",
        en: "https://talap.online/",
      },
    },
  };
}

export const viewport: Viewport = {
  // Matches --color-paper. The old #f3f3f3 was the cold grey the pilots
  // reacted to; the browser chrome should agree with the new canvas.
  themeColor: "#fbfaf6",
  colorScheme: "light",
  width: "device-width",
  initialScale: 1,
  // Never lock zoom on a study tool — students pinch into diagrams constantly,
  // and 14 of 26 pilots were on a phone.
  maximumScale: 5,
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const locale = await resolveLocale();

  return (
    <html lang={LOCALE_TAG[locale]} className={inter.variable}>
      <body>
        <LocaleProvider initial={locale}>
          <SessionProvider>
            {children}
            <AskTalap />
          </SessionProvider>
        </LocaleProvider>
      </body>
    </html>
  );
}
